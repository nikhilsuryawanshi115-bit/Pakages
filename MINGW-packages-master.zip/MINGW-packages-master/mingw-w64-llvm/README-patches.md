# Patches statuses

Legend:

- :grey_exclamation: - not meant to upstream, for compatibility with GCC only
- :x: - not upstreamed
- :grey_question: - sent but not merged yet
- :arrow_up_small:  - upstreamed
- :arrow_down_small:  - backported

-----

- `"0001-Fix-GetHostTriple-for-mingw-w64-in-msys.patch"` :x:
- `"0002-Fix-Findzstd-on-MINGW.patch"` :x:
- `"0003-add-pthread-as-system-lib-for-mingw.patch"` :grey_exclamation:
- `"0101-link-pthread-with-mingw.patch"` :grey_exclamation:
- `"0303-ignore-new-bfd-options.patch"` :x:
